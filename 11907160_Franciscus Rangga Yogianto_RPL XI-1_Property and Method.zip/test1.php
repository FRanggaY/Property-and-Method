<?php
//Cetak Kendaraan
class Kendaraan{
    public $merk, 
           $warna,
           $harga;
    
    public function getCetak(){
        return "$this->merk, $this->warna, $this->harga";
    }
}

$mobil = new Kendaraan();
$mobil->merk = "Toyota";
$mobil->warna = "Hitam";
$mobil->harga = 12000000;

$motor = new Kendaraan();
$motor->merk = "Honda";
$motor->warna = "Putih";
$motor->harga = 1000000;

echo "Mobil : " . $mobil->getCetak();
echo "<br>";
echo "Motor : " . $motor->getCetak();

?>